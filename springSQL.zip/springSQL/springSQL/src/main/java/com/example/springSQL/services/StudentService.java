package com.example.springSQL.services;

import com.example.springSQL.model.Student;
import com.example.springSQL.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {

    @Autowired
    private StudentRepository sr;

    public List<Student> getAllStudents() {
        return sr.findAll();
    }

    public Student addStudent(Student s) {
        return sr.save(s);
    }
}
