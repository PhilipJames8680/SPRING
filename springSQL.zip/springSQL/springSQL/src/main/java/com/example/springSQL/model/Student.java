package com.example.springSQL.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;



@Data
@AllArgsConstructor
public class Student {

    @Id
    private int no;
    private String name;
    private String tech;
}
