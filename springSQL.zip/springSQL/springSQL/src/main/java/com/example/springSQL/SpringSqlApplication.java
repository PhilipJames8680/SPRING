package com.example.springSQL;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSqlApplication.class, args);
	}

}
