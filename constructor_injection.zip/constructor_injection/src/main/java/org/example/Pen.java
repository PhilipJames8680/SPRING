package org.example;

public class Pen {

    public void draw()
    {
        System.out.println("Drawing an Image Now ! Teacher :)");
    }

}
