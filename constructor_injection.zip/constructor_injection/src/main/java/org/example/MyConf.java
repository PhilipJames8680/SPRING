package org.example;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MyConf {

    @Bean(name = "p")
    public Pen pen()
    {
        return new Pen();
    }

    @Bean(name="s")
    public Student s(Pen pen)
    {
        return new Student(pen);
    }


}
