package org.example;

public class Student {

    private Pen pen;

    public Pen getPen() {
        return pen;
    }

    public void setPen(Pen pen) {
        this.pen = pen;
    }

    public Student(Pen pen)
    {
        this.pen=pen;
    }

    public void write()
    {
        pen.draw();
    }


}
