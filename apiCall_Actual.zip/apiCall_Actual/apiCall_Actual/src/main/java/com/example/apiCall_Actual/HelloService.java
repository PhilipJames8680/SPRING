package com.example.apiCall_Actual;

import org.springframework.stereotype.Service;

@Service
public class HelloService {

    public String getGreeting() {
        return "Hello from Service Layer 🚀";
    }

    public String getAboutMessage() {
        return "This response is coming from HelloService";
    }
}
