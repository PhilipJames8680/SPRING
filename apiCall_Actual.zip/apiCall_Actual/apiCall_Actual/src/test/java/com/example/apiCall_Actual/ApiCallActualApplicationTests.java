package com.example.apiCall_Actual;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiCallActualApplicationTests {

	@Test
	void contextLoads() {
	}

}
