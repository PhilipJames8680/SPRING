package com.example.demoSecurity.configure;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.CsrfConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class StudentConfiguration {

    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        http
                // Disable CSRF (stateless REST API)
                .csrf(csrf -> csrf.disable())

                // Authorization via AuthorizationManagerRequestMatcherRegistry
                .authorizeHttpRequests(auth -> auth
                        .anyRequest().authenticated()
                )

                // HTTP Basic authentication
                .httpBasic(Customizer.withDefaults())

                // No HttpSession, no JSESSIONID
                .sessionManagement(session ->
                        session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                );

        return http.build();
    }
}

