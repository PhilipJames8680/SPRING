package org.example;


import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
public class Pen implements Writer{
    public void exam()
    {
        System.out.println("Pen is Used");
    }
}
