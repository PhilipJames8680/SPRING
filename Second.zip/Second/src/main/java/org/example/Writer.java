package org.example;

public interface Writer {
    void exam();
}
