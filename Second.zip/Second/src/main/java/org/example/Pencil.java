package org.example;

import org.springframework.stereotype.Component;

@Component
public class Pencil implements Writer{

    public void exam()
    {
        System.out.println("Pencil is used");
    }


}
