package org.example;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
@Data // Automatically does the getter setter for private.
public class Student {

    private int rollno;
    private Writer w;
    @Autowired
    public void write()
        {
            System.out.println("Student is writing the exam");
        }

}
