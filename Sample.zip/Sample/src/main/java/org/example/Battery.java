package org.example;

public class Battery implements vehicle{

    public Battery() {

    }

    public void move()
    {
        System.out.println("Battery Started");
    }

}
