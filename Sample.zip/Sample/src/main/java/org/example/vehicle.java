package org.example;

public interface vehicle {
    void move();
}
