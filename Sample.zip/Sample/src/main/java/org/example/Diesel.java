package org.example;

public class Diesel {

    private int fuel;
    private int rollno;
    private vehicle v;

    public Diesel(int fuel, int rollno, vehicle v) {
        this.fuel = fuel;
        this.rollno = rollno;
        this.v = v;
    }

    public Diesel(){

    }

    public void work()
    {
        System.out.println("Its working");
    }


}
