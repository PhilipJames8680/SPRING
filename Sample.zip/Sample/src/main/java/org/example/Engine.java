package org.example;

public class Engine implements vehicle{
////    public Engine()
////    {
////        System.out.println("Successful !");
////    }
//
//    // Even without constructor , it works.
//
//    public void stopEngine()
//    {
//        System.out.println("Engine has Stopped");
//    }
//    public void startEngine()
//
//    {
//        System.out.println("Engine has Started");
//    }


    public void move()
    {
        System.out.println("Engine Started");
    }

}
