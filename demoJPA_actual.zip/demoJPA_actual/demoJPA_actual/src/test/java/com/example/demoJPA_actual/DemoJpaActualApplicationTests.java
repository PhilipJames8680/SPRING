package com.example.demoJPA_actual;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoJpaActualApplicationTests {

	@Test
	void contextLoads() {
	}

}
