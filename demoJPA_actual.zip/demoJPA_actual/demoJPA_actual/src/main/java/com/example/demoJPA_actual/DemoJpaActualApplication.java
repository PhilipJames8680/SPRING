package com.example.demoJPA_actual;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoJpaActualApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoJpaActualApplication.class, args);
	}

}
