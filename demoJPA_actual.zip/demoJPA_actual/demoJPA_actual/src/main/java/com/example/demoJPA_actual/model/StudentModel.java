package com.example.demoJPA_actual.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class StudentModel {

    @Id
    private int no;
    private String name;
    private String tech;
    private String gender;
}


